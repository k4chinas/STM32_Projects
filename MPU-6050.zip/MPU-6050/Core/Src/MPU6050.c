/*
 * MPU6050.c
 *
 *  Created on: Dec 27, 2025
 *      Author: k4chinas
 */
#include <MPU6050.h>

void MPU6050_Sensivity_Selector(MPU6050 *mpu, Accel_Scale aScale, Gyro_Scale gScale){
	mpu->aScale = aScale;
	mpu->gScale = gScale;

	//For Acceleration
	switch(aScale) {
	case ACCEL_SCALE_2G:  mpu->aMult = 1.0f / 16384.0f; break;
	case ACCEL_SCALE_4G:  mpu->aMult = 1.0f / 8192.0f;  break;
	case ACCEL_SCALE_8G:  mpu->aMult = 1.0f / 4096.0f;  break;
	case ACCEL_SCALE_16G: mpu->aMult = 1.0f / 2048.0f;  break;
	default: mpu->aMult = 1.0f / 16384.0f; break;
	}

	//For Gyro:
	switch(gScale) {
	case GYRO_SCALE_250DPS:  mpu->gMult = 1.0f / 131.0f;  break;
	case GYRO_SCALE_500DPS:  mpu->gMult = 1.0f / 65.5f;   break;
	case GYRO_SCALE_1000DPS: mpu->gMult = 1.0f / 32.8f;   break;
	case GYRO_SCALE_2000DPS: mpu->gMult = 1.0f / 16.4f;   break;
	default: mpu->gMult = 1.0f / 131.0f; break;
	}
}
uint8_t Calculate_Sample_Divider(int output_rate, int period_hz) {
    if (period_hz == 0) return 0;
    int calculated_val = (output_rate / period_hz) - 1;
    if (calculated_val > 255){
        return 0xFF;
    }
    if (calculated_val < 0){
        return 0x00;
    }
    return (uint8_t)calculated_val;
}


void MPU6050_Config(MPU6050 *mpu, I2C_HandleTypeDef *hi2c, Gyro_Scale fs_sens, Accel_Scale afs_sens, DLPF_CFG dlpf, int Period_Hz){
	int Output_Rate;
	uint8_t temp_data;
	if(dlpf != 0x00){
		Output_Rate = 1000;
	}else Output_Rate = 8000;
	uint8_t SAMPLE_DIV = Calculate_Sample_Divider(Output_Rate, Period_Hz);

    temp_data = (uint8_t)fs_sens;
    HAL_I2C_Mem_Write(mpu->hi2c, MPU_ADDR, GYRO_CONFIG, 1, &temp_data, 1, 100);
    temp_data = (uint8_t)dlpf;
    HAL_I2C_Mem_Write(mpu->hi2c, MPU_ADDR, CONFIG, 1, &temp_data, 1, 100);
    temp_data = (uint8_t)SAMPLE_DIV;
    HAL_I2C_Mem_Write(mpu->hi2c, MPU_ADDR, SMPLRT_DIV, 1, &temp_data, 1, 100);
    temp_data = (uint8_t)afs_sens;
    HAL_I2C_Mem_Write(mpu->hi2c, MPU_ADDR, ACCEL_CONFIG, 1, &temp_data, 1, 100);
}

void MPU6050_Init(MPU6050 *mpu, I2C_HandleTypeDef *hi2c, Accel_Scale afs_sens, Gyro_Scale fs_sens, DLPF_CFG dlpf, int Period_Hz){
	mpu->hi2c = hi2c;
	uint8_t data = 0;
	HAL_I2C_Mem_Read(mpu->hi2c, MPU_ADDR, WHO_AM_I, 1, &data, 1, 100);

	if(data == 0x68){
		uint8_t pwr_data = 0x00;
		HAL_I2C_Mem_Write(mpu->hi2c, MPU_ADDR, PWR_MGMT_1, 1, &pwr_data, 1, 100);
		HAL_Delay(100);
	}

	data = (uint8_t)fs_sens;
	HAL_I2C_Mem_Write(mpu->hi2c, MPU_ADDR, GYRO_CONFIG, 1, &data, 1, 100);

	data = (uint8_t)afs_sens;
	HAL_I2C_Mem_Write(mpu->hi2c, MPU_ADDR, ACCEL_CONFIG, 1, &data, 1, 100);

	MPU6050_Sensivity_Selector(mpu, afs_sens, fs_sens);
	MPU6050_Config(mpu, mpu->hi2c, fs_sens, afs_sens, dlpf, Period_Hz);
}

void MPU6050_Read_Gyro(MPU6050 *mpu){
    uint8_t Gyro_Raw[6];
    HAL_I2C_Mem_Read(mpu->hi2c, MPU_ADDR, GYRO_XOUT_H, 1, Gyro_Raw, 6, 100);
    mpu->Gyro_Raw[0] = (int16_t)(Gyro_Raw[0] << 8 | Gyro_Raw[1]);
    mpu->Gyro_Raw[1] = (int16_t)(Gyro_Raw[2] << 8 | Gyro_Raw[3]);
    mpu->Gyro_Raw[2] = (int16_t)(Gyro_Raw[4] << 8 | Gyro_Raw[5]);

    mpu->Gx = mpu->Gyro_Raw[0] * mpu->gMult;
    mpu->Gy = mpu->Gyro_Raw[1] * mpu->gMult;
    mpu->Gz = mpu->Gyro_Raw[2] * mpu->gMult;
}

void MPU6050_Read_Accel(MPU6050 *mpu){
    uint8_t Accel_Raw[6];
    HAL_I2C_Mem_Read(mpu->hi2c, MPU_ADDR, ACCEL_XOUT_H, 1, Accel_Raw, 6, 100);
    mpu->Accel_Raw[0] = (int16_t)(Accel_Raw[0] << 8 | Accel_Raw[1]);
    mpu->Accel_Raw[1] = (int16_t)(Accel_Raw[2] << 8 | Accel_Raw[3]);
    mpu->Accel_Raw[2] = (int16_t)(Accel_Raw[4] << 8 | Accel_Raw[5]);

    mpu->Ax = mpu->Accel_Raw[0] * mpu->aMult;
    mpu->Ay = mpu->Accel_Raw[1] * mpu->aMult;
    mpu->Az = mpu->Accel_Raw[2] * mpu->aMult;
}

void MPU6050_Read_Temp(MPU6050 *mpu){
    uint8_t Temp_Raw[2];
    HAL_I2C_Mem_Read(mpu->hi2c, MPU_ADDR, TEMP_OUT_H, 1, Temp_Raw, 2, 100);
    mpu->Temperature = (((int16_t)(Temp_Raw[0] << 8 | Temp_Raw[1])) / 340.0f) + 36.53f;
}
void MPU6050_Read_All(MPU6050 *mpu){
	MPU6050_Read_Accel(mpu);
	MPU6050_Read_Gyro(mpu);
	MPU6050_Read_Temp(mpu);
}

void MPU6050_Calculate_Angles(MPU6050 *mpu, double dt){
    double accel_roll = atan2(mpu->Ay, mpu->Az) * 57.296;
    double accel_pitch = atan2(-(mpu->Ax), sqrt(mpu->Ay * mpu->Ay + mpu->Az * mpu->Az)) * 57.296;

    mpu->Angle_X = 0.96 * (mpu->Angle_X + mpu->Gx * dt) + 0.04 * accel_roll;
    mpu->Angle_Y = 0.96 * (mpu->Angle_Y + mpu->Gy * dt) + 0.04 * accel_pitch;
}
