/*
 * MPU6050.h
 *
 *  Created on: Dec 27, 2025
 *      Author: k4chinas
 */

#ifndef INC_MPU6050_H_
#define INC_MPU6050_H_

#include "stdio.h"
#include "stdlib.h"
#include "main.h"
#include "math.h"
#include <MPU6050_addr.h>

typedef struct {
	I2C_HandleTypeDef *hi2c;

    Accel_Scale aScale;
    Gyro_Scale gScale;

    float aMult; // Multiplier converting raw data to g
    float gMult; // Multiplier converting raw data to dps

	int16_t Accel_Raw[3];
	int16_t Gyro_Raw[3];

	float Ax, Ay, Az;
	float Gx, Gy, Gz;

    float Temperature;

	float Angle_X;  // Angle around the X axis (Roll)
	float Angle_Y; // Angle around the Y axis (Pitch)
}MPU6050;

void MPU6050_Init(MPU6050 *mpu, I2C_HandleTypeDef *hi2c, Accel_Scale afs_sens, Gyro_Scale fs_sens, DLPF_CFG dlpf, int Period_Hz);

void MPU6050_Read_Gyro(MPU6050 *mpu);
void MPU6050_Read_Accel(MPU6050 *mpu);
void MPU6050_Read_Temp(MPU6050 *mpu);
void MPU6050_Read_All(MPU6050 *mpu);

void MPU6050_Calculate_Angles(MPU6050 *mpu, double dt);

#endif /* INC_MPU6050_H_ */
