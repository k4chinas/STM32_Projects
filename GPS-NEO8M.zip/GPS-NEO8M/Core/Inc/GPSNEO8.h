/*
 * GPSNEO8.h
 *
 * Created on: Dec 26, 2025
 * Author: k4chinas
 */

#ifndef INC_GPSNEO8_H_
#define INC_GPSNEO8_H_

#include "main.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#define MAX_WAYPOINTS 20 // Maximum number of waypoints in a route

typedef enum {
    GPS_MODEL_PORTABLE   = 0, // Default mode (General purpose)
    GPS_MODEL_STATIONARY = 2, // Stationary (Timing only)
    GPS_MODEL_PEDESTRIAN = 3, // Pedestrian (Low speed, high agility)
    GPS_MODEL_AUTOMOTIVE = 4, // Automotive (High speed, 2D movement)
    GPS_MODEL_AIRBORNE_1G= 6, // Airborne <1g (Drone/Quadcopter)
    GPS_MODEL_AIRBORNE_2G= 7  // Airborne <2g (High speed aircraft)
} GPS_DynamicModel;

typedef enum {
    GPS_RESET_HOT  = 0x00, // Hot Start (Quickest, uses saved data)
    GPS_RESET_WARM = 0x01, // Warm Start (Clears ephemeris)
    GPS_RESET_COLD = 0xFF  // Cold Start (Factory reset, clears all)
} GPS_ResetType;

typedef enum {
    UBX_WAIT_SYNC1 = 0,   // Waiting for 0xB5
    UBX_WAIT_SYNC2,       // Waiting for 0x62
    UBX_WAIT_CLASS,       // Reading Class Byte
    UBX_WAIT_ID,          // Reading ID Byte
    UBX_WAIT_LEN_LOW,     // Reading Length Low Byte
    UBX_WAIT_LEN_HIGH,    // Reading Length High Byte
    UBX_READ_PAYLOAD      // Reading Data Payload
} UBX_State;

typedef enum {
    GPS_POWER_FULL     = 0, // Full Power (Max accuracy, ~35mA)
    GPS_POWER_BALANCED = 1, // Balanced (Performance/Power, ~25mA)
    GPS_POWER_INTERVAL = 2, // Interval (Periodic wake up)
    GPS_POWER_SAVE     = 3  // Power Save (1Hz, ~10mA)
} GPS_PowerMode;

typedef enum {
    TYPE_SKIP,       // Skip this field
    TYPE_CHAR,       // Character (N, S, E, W, etc.)
    TYPE_INT,        // Integer value
    TYPE_FLOAT,      // Float value
    TYPE_COORDINATE, // Special: Convert NMEA to Decimal degrees
    TYPE_TIME,       // Special: Parse HHMMSS to struct
    TYPE_DATE        // Special: Parse DDMMYY to struct
} DataType;

/********************************************* FOR DRONE NAVIGATION **************************************************************/

typedef struct {
    float targetLat; // Target Latitude
    float targetLon; // Target Longitude
} GPS_Target;

typedef struct {
    float distanceMeters;  // Distance to target in meters
    float bearingDegree;   // Bearing to target (0-360 deg)
    float errorDegree;     // Course deviation error (Required turn angle)
} GPS_Navigation;

typedef struct {
    float lat; // Waypoint Latitude
    float lon; // Waypoint Longitude
} GPS_Waypoint;

typedef struct {
    GPS_Waypoint points[MAX_WAYPOINTS]; // Array of route points
    uint8_t totalCount;     // Total points in the route
    uint8_t currentIndex;   // Index of the current target point
    float acceptanceRadius; // Radius to consider point reached (meters)
    uint8_t isFinished;     // Flag: Route completed
    uint8_t isActive;       // Flag: Route following is active
} GPS_RouteManager;

/********************************************* CORE GPS DATA STRUCTURES ********************************************************/

typedef struct {
    void *targetVariable; // Pointer to destination variable
    DataType type;      // Data type enum
} NMEA_Field_Map;

typedef struct{
    float latitude;         // Latitude (Decimal)
    char lat_d;             // Latitude Direction (N/S)
    float longitude;        // Longitude (Decimal)
    char lon_d;             // Longitude Direction (E/W)
    float altitude;         // Altitude above sea level (Meters)
    float geoidSeparation;  // Geoid separation (Meters)
} GPS_Coordinate;

typedef struct {
    uint8_t hours;   // Hour (UTC)
    uint8_t minutes; // Minute
    uint8_t seconds; // Second
    uint8_t day;     // Day
    uint8_t month;   // Month
    uint16_t year;   // Year
} GPS_Time;

typedef struct {
    float speedKnots;   // Speed in Knots
    float speedKm;      // Speed in Km/h
    float courseDegree; // Heading/Track angle (0-360)
} GPS_Motion;

typedef struct {
    uint8_t satelliteID;    // Satellite PRN Number
    uint8_t elevation;      // Elevation Angle
    uint8_t azimuth;        // Azimuth Angle
    uint8_t snr;            // Signal-to-Noise Ratio (dBHz)
} GPS_Satellite;

typedef struct {
    uint8_t fixQuality;     // Fix type (0:None, 1:GPS, 2:DGPS)
    uint8_t satellitesUsed; // Number of sats used for solution
    uint8_t satellitesView; // Total sats in view
    float HDOP;             // Horizontal Dilution of Precision
    float VDOP;             // Vertical Dilution of Precision
    float PDOP;             // Positional Dilution of Precision
    GPS_Satellite satsInView[15]; // Array of detailed sat info
} GPS_Status;

typedef struct {
    uint8_t jammingState;     // 0:OK, 1:Warning, 2:Critical
    uint8_t jammingIndicator; // CW jamming level (0-255)
    uint8_t spoofingState;    // 0:None, 1:Spoofing suspected
    uint8_t noiseLevel;       // Noise floor level
} GPS_Security;

// --- MAIN OBJECT ---
typedef struct {
    GPS_Coordinate location; // Position data
    GPS_Time       time;     // Time and Date data
    GPS_Motion     motion;   // Speed and Heading data
    GPS_Status     status;   // Satellite status and precision
    GPS_Security   security; // Jamming and spoofing status

    GPS_Target     target;      // Current single target
    GPS_Navigation nav;         // Navigation calculations
    GPS_RouteManager route;     // Waypoint management

    uint8_t        newDataAvailable; // Flag: New NMEA packet received
} NEO8M_GPS;

/********************************************* CORE GPS FUNCTIONS **************************************************************/

void GPS_Init(UART_HandleTypeDef *huart);                         // Initialize DMA and Buffer
void GPS_Process(UART_HandleTypeDef *huart);                      // Main loop to parse incoming data
void GPS_Send_UBX(UART_HandleTypeDef *huart, uint8_t classID, uint8_t msgID, uint8_t *payload, uint16_t length); // Send generic UBX packet
void GPS_Set_BaudRate(UART_HandleTypeDef *huart, uint32_t baudrate, int delay_ms); // Set module baudrate
void GPS_Set_Rate(UART_HandleTypeDef *huart, uint16_t period_ms, int delay_ms);    // Set update rate (e.g. 100ms = 10Hz)
void GPS_Save_Configuration(UART_HandleTypeDef *huart);           // Save settings to BBR/Flash

void GPS_Configration_Full(UART_HandleTypeDef *huart, int BaudRate, int Period_ms, int minAngle, int GPS_PowerMode, int GPS_DynamicModel);
void GPS_Configure_System9600toAny(UART_HandleTypeDef *huart, uint32_t targetBaudRate, uint16_t updatePeriod_ms); // Full setup sequence
void GPS_Set_DynamicModel(UART_HandleTypeDef *huart, GPS_DynamicModel model); // Set mode (Drone/Car/Pedestrian)
void GPS_Enable_Galileo_GLONASS(UART_HandleTypeDef *huart);       // Enable multi-GNSS constellations
void GPS_Force_Reset(UART_HandleTypeDef *huart, GPS_ResetType type); // Force Hot/Warm/Cold start

void GPS_Set_MinElevation(UART_HandleTypeDef *huart, uint8_t minAngle); // Set minimum satellite elevation mask
void GPS_Set_PowerMode(UART_HandleTypeDef *huart, GPS_PowerMode mode);  // Set power management mode

void GPS_Poll_Security_Status(UART_HandleTypeDef *huart);         // Request Jamming status (MON-HW)
void GPS_Jammer_Control(UART_HandleTypeDef *huart);               // Handle Jamming logic

/********************************************* FOR DRONE NAVIGATION FUNCTIONS **************************************************/

void GPS_Set_Target(float lat, float lon);                        // Set a single target coordinate
void GPS_Calculate_Navigation(void);                              // Calculate distance and bearing to target

void GPS_Route_Init(float radiusMeters);                          // Initialize route manager
void GPS_Route_Add(float lat, float lon);                         // Add a point to the route list
void GPS_Route_Update(void);                                      // Check distance and switch waypoints
void GPS_Route_Start(void);                                       // Start following the route

void GPS_Route_Check(void);
/******************************************************************************************************************************/

#endif /* INC_GPSNEO8_H_ */
