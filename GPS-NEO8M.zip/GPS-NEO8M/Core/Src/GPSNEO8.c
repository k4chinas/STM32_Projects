/*
 * GPSNEO8.c
 *
 * Created on: Dec 26, 2025
 * Author: k4chinas
 */

#include <GPSNEO8.h>
#include "math.h"

#define GPS_BUFFER_SIZE 1024
#define MAX_SATS_IN_VIEW 15

#define EARTH_RADIUS 6371000.0f
#define TO_RAD (3.14159265f / 180.0f)
#define TO_DEG (180.0f / 3.14159265f)

// Global Variables
extern NEO8M_GPS gps;
extern uint8_t rxBuffer[GPS_BUFFER_SIZE];
uint16_t tailIndex = 0;
char lineBuffer[256];

/**
  * @brief  Converts NMEA coordinate format (DDMM.MMMM) to Decimal Degrees.
  * @note   Example: 4100.0000 becomes 41.000000.
  * @param  nmeaRaw: Raw float value from NMEA sentence
  * @retval Decimal degree float value
  */
float Convert_Coordinate(float nmeaRaw) {
    if (nmeaRaw == 0.0f) return 0.0f;
    int degrees = (int)(nmeaRaw / 100);
    float minutes = nmeaRaw - (degrees * 100);
    return degrees + (minutes / 60.0f);
}

/**
  * @brief  Validates the NMEA sentence checksum.
  * @note   Calculates XOR of characters between '$' and '*'.
  * @param  string: Pointer to the NMEA sentence
  * @retval 1 if checksum matches, 0 if failed
  */
uint8_t Validate_Checksum(char *string) {
    char *start = strchr(string, '$');
    char *end = strchr(string, '*');
    if (start == NULL || end == NULL) return 0;

    uint8_t calcs = 0;
    for (char *p = start + 1; p < end; p++) {
        calcs ^= *p;
    }

    uint8_t rcvs = (uint8_t)strtol(end + 1, NULL, 16);
    return (calcs == rcvs);
}

/**
  * @brief  Parses a comma-separated string to get the next token.
  * @param  ptr: Address of the current string pointer
  * @retval Pointer to the start of the token
  */
char* Get_Next_Token(char **ptr) {
    char *start = *ptr;
    if (start == NULL) return NULL;

    char *comma = strchr(start, ',');
    if (comma != NULL) {
        *comma = '\0';
        *ptr = comma + 1;
    } else {
        *ptr = NULL;
    }
    return start;
}

/**
  * @brief  Parses NMEA payload based on a provided field map.
  * @param  payload: Pointer to the NMEA data string (after the comma)
  * @param  map: Pointer to the NMEA_Field_Map array
  * @param  mapSize: Number of fields in the map
  * @retval None
  */
void Parse_With_Map(char *payload, NMEA_Field_Map *map, int mapSize) {
    char *cursor = payload;
    char *token;
    int index = 0;

    while ((token = Get_Next_Token(&cursor)) != NULL && index < mapSize) {

        if (strlen(token) == 0) {
            index++;
            continue;
        }

        void *target = map[index].targetVariable;
        DataType type = map[index].type;

        if (target == NULL && type != TYPE_SKIP) { index++; continue; }

        switch (type) {
            case TYPE_CHAR:
                *(char*)target = token[0];
                break;
            case TYPE_INT:
                *(uint8_t*)target = (uint8_t)atoi(token);
                break;
            case TYPE_FLOAT:
                *(float*)target = (float)atof(token);
                break;
            case TYPE_COORDINATE:
                *(float*)target = Convert_Coordinate((float)atof(token));
                break;
            case TYPE_TIME:
                if (strlen(token) >= 6) {
                    char tmp[3] = {0};
                    strncpy(tmp, token, 2);   ((GPS_Time*)target)->hours = (uint8_t)atoi(tmp);
                    strncpy(tmp, token+2, 2); ((GPS_Time*)target)->minutes = (uint8_t)atoi(tmp);
                    strncpy(tmp, token+4, 2); ((GPS_Time*)target)->seconds = (uint8_t)atoi(tmp);
                }
                break;
            case TYPE_DATE:
                if (strlen(token) >= 6) {
                    char tmp[3] = {0};
                    strncpy(tmp, token, 2);   ((GPS_Time*)target)->day = (uint8_t)atoi(tmp);
                    strncpy(tmp, token+2, 2); ((GPS_Time*)target)->month = (uint8_t)atoi(tmp);
                    strncpy(tmp, token+4, 2); ((GPS_Time*)target)->year = 2000 + (uint16_t)atoi(tmp);
                }
                break;
            case TYPE_SKIP:
            default:
                break;
        }
        index++;
    }
}

/**
  * @brief  Special parser for GSV (Satellites in View) messages.
  * @note   Loops through blocks of 4 satellites per message.
  * @param  payload: Pointer to the GSV data string
  * @retval None
  */
void Parse_GSV(char *payload) {
    char *cursor = payload;
    char *token;

    Get_Next_Token(&cursor);

    token = Get_Next_Token(&cursor);
    int msgNum = atoi(token);

    token = Get_Next_Token(&cursor);
    gps.status.satellitesView = (uint8_t)atoi(token);

    int satIndex = (msgNum - 1) * 4;

    for (int i = 0; i < 4; i++) {
        if (satIndex >= MAX_SATS_IN_VIEW) break;

        token = Get_Next_Token(&cursor);
        if (token == NULL) break;
        gps.status.satsInView[satIndex].satelliteID = (uint8_t)atoi(token);

        token = Get_Next_Token(&cursor);
        gps.status.satsInView[satIndex].elevation = (uint8_t)(token ? atoi(token) : 0);

        token = Get_Next_Token(&cursor);
        gps.status.satsInView[satIndex].azimuth = (uint8_t)(token ? atoi(token) : 0);

        token = Get_Next_Token(&cursor);
        gps.status.satsInView[satIndex].snr = (uint8_t)(token ? atoi(token) : 0);

        satIndex++;
    }
}


// Mapping arrays for NMEA parsing
NMEA_Field_Map map_RMC[] = {
    { &gps.time,              TYPE_TIME },
    { NULL,                       TYPE_SKIP },
    { &gps.location.latitude, TYPE_COORDINATE },
    { &gps.location.lat_d,    TYPE_CHAR },
    { &gps.location.longitude,TYPE_COORDINATE },
    { &gps.location.lon_d,    TYPE_CHAR },
    { &gps.motion.speedKnots, TYPE_FLOAT },
    { &gps.motion.courseDegree,TYPE_FLOAT },
    { &gps.time,              TYPE_DATE },
    { NULL,                       TYPE_SKIP },
    { NULL,                       TYPE_SKIP }
};

NMEA_Field_Map map_GGA[] = {
    { NULL,                       TYPE_SKIP },
    { NULL,                       TYPE_SKIP },
    { NULL,                       TYPE_SKIP },
    { NULL,                       TYPE_SKIP },
    { NULL,                       TYPE_SKIP },
    { &gps.status.fixQuality, TYPE_INT },
    { &gps.status.satellitesUsed, TYPE_INT },
    { &gps.status.HDOP,       TYPE_FLOAT },
    { &gps.location.altitude, TYPE_FLOAT },
    { NULL,                       TYPE_SKIP },
    { &gps.location.geoidSeparation, TYPE_FLOAT },
    { NULL,                       TYPE_SKIP }
};


NMEA_Field_Map map_GSA[] = {
    { NULL, TYPE_SKIP },
    { NULL, TYPE_SKIP },
    { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP },
    { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP },
    { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP }, { NULL, TYPE_SKIP },
    { &gps.status.PDOP, TYPE_FLOAT },
    { &gps.status.HDOP, TYPE_FLOAT },
    { &gps.status.VDOP, TYPE_FLOAT }
};

/********************************************* CORE GPS FUNCTIONS **************************************************************/

/**
  * @brief  Initializes the GPS Module.
  * @note   Clears the buffer and starts DMA reception.
  * @param  huart: Pointer to the UART handle
  * @retval None
  */
void GPS_Init(UART_HandleTypeDef *huart) {
	memset(rxBuffer, 0, GPS_BUFFER_SIZE);
    tailIndex = 0;
    HAL_UART_Receive_DMA(huart, rxBuffer, GPS_BUFFER_SIZE);
}

/**
  * @brief  Main processing loop for GPS data.
  * @note   This function handles both NMEA (Text) and UBX (Binary) protocols simultaneously.
  * It must be called inside the main while(1) loop.
  *
  * @verbatim
  * Parsing Logic:
  * 1. Reads from DMA Circular Buffer.
  * 2. Checks for UBX Binary Headers (0xB5 0x62) for Jamming/Security data.
  * 3. Checks for NMEA ASCII Headers ('$') for Position/Time data.
  * @endverbatim
  *
  * @param  huart: Pointer to the UART handle
  * @retval None
  */
void GPS_Process(UART_HandleTypeDef *huart) {
    uint16_t headIndex = GPS_BUFFER_SIZE - __HAL_DMA_GET_COUNTER(huart->hdmarx);

    while (tailIndex != headIndex) {
        uint8_t incoming = rxBuffer[tailIndex];

        // --- UBX PARSER VARIABLES ---
        static uint8_t ubxState = 0;
        static uint8_t ubxClass, ubxID;
        static uint16_t ubxLen, ubxCount;
        static uint8_t ubxPayload[100];

        // --- 1. UBX PARSER (Hybrid state machine) ---

        // Step 0: Wait for Sync 1 (0xB5)
        if (ubxState == 0) {
            if (incoming == 0xB5) ubxState = 1;
        }
        // Step 1: Wait for Sync 2 (0x62)
        else if (ubxState == 1) {
            if (incoming == 0x62) ubxState = 2;
            else ubxState = 0;
        }
        // Step 2: Read Class
        else if (ubxState == 2) {
            ubxClass = incoming;
            ubxState = 3;
        }
        // Step 3: Read ID
        else if (ubxState == 3) {
            ubxID = incoming;
            ubxState = 4;
        }
        // Step 4: Length Low
        else if (ubxState == 4) {
            ubxLen = incoming;
            ubxState = 5;
        }
        // Step 5: Length High & Prep
        else if (ubxState == 5) {
            ubxLen |= (incoming << 8);
            ubxCount = 0;

            // Security: Prevent buffer overflow
            if (ubxLen > 100) ubxState = 0;
            else ubxState = 6;
        }
        // Step 6: Read Payload
        else if (ubxState == 6) {
            ubxPayload[ubxCount] = incoming;
            ubxCount++;

            // Packet Complete
            if (ubxCount >= ubxLen) {
                // Check for MON-HW (Jamming Status)
                if (ubxClass == 0x0A && ubxID == 0x09 && ubxLen >= 46) {
                    gps.security.jammingState = (ubxPayload[17] >> 2) & 0x03;
                    gps.security.noiseLevel = ubxPayload[22];
                    gps.security.jammingIndicator = ubxPayload[45];
                }
                ubxState = 0; // Reset
            }
        }

        // --- 2. NMEA PARSER (Legacy Text Parser) ---
        static uint16_t idx = 0;

        if (incoming == '$') {
            idx = 0;
            lineBuffer[idx++] = incoming;
        }
        else if (incoming == '\n') {
            lineBuffer[idx] = '\0';
            if (Validate_Checksum(lineBuffer)) {
                char *payload = strchr(lineBuffer, ',');
                if (payload != NULL) {
                    payload++;
                    if (strstr(lineBuffer, "RMC")) {
                        Parse_With_Map(payload, map_RMC, sizeof(map_RMC)/sizeof(NMEA_Field_Map));
                        gps.motion.speedKm = gps.motion.speedKnots * 1.852f;
                        gps.newDataAvailable = 1;
                    }
                    else if (strstr(lineBuffer, "GGA")) {
                        Parse_With_Map(payload, map_GGA, sizeof(map_GGA)/sizeof(NMEA_Field_Map));
                    }
                    else if (strstr(lineBuffer, "GSA")) {
                        Parse_With_Map(payload, map_GSA, sizeof(map_GSA)/sizeof(NMEA_Field_Map));
                    }
                    else if (strstr(lineBuffer, "GSV")) {
                        Parse_GSV(payload);
                    }
                }
            }
            idx = 0;
        }
        else {
            if (idx < 255) lineBuffer[idx++] = incoming;
        }

        tailIndex++;
        if (tailIndex >= GPS_BUFFER_SIZE) tailIndex = 0;
    }
}

/**
  * @brief  Calculates the Fletcher Checksum (RFC 1145) for UBX protocol.
  * @param  buffer: Pointer to the payload buffer
  * @param  length: Length of the payload
  * @param  ck_a: Pointer to store Checksum A
  * @param  ck_b: Pointer to store Checksum B
  * @retval None
  */
void UBX_Calc_Checksum(uint8_t *buffer, uint16_t length, uint8_t *ck_a, uint8_t *ck_b) {
    *ck_a = 0;
    *ck_b = 0;
    for (uint16_t i = 0; i < length; i++) {
        *ck_a = *ck_a + buffer[i];
        *ck_b = *ck_b + *ck_a;
    }
}

/**
  * @brief  Constructs and sends a UBX packet via UART.
  * @note   Automatically calculates checksum and adds header/footer.
  * @param  huart: Pointer to UART handle
  * @param  classID: UBX Class ID (e.g., 0x06 for CFG)
  * @param  msgID: UBX Message ID (e.g., 0x00 for PRT)
  * @param  payload: Pointer to data payload
  * @param  len: Length of payload
  * @retval None
  */
void GPS_Send_UBX(UART_HandleTypeDef *huart, uint8_t classID, uint8_t msgID, uint8_t *payload, uint16_t len) {
    uint8_t frame[50];
    uint8_t idx = 0;
    uint8_t ck_a, ck_b;

    frame[idx++] = 0xB5;
    frame[idx++] = 0x62;

    frame[idx++] = classID;
    frame[idx++] = msgID;

    frame[idx++] = len & 0xFF;
    frame[idx++] = (len >> 8) & 0xFF;

    if (len > 0) {
        memcpy(&frame[idx], payload, len);
        idx += len;
    }

    UBX_Calc_Checksum(&frame[2], idx - 2, &ck_a, &ck_b);

    frame[idx++] = ck_a;
    frame[idx++] = ck_b;

    HAL_UART_Transmit(huart, frame, idx, 100);
}

/**
  * @brief  Sets the GPS Module Baud Rate using UBX-CFG-PRT.
  * @param  huart: Pointer to UART handle
  * @param  baudrate: Desired baud rate (e.g., 115200)
  * @param  delay_ms: Delay after sending command to allow module to switch
  * @retval None
  */
void GPS_Set_BaudRate(UART_HandleTypeDef *huart, uint32_t baudrate, int delay_ms){
    uint8_t payload[20] = {0};

    payload[0] = 0x01;
    payload[4] = 0xC0;
    payload[5] = 0x08;
    payload[8]  = baudrate & 0xFF;         // En düşük byte
    payload[9]  = (baudrate >> 8) & 0xFF;  // 2. byte
    payload[10] = (baudrate >> 16) & 0xFF; // 3. byte
    payload[11] = (baudrate >> 24) & 0xFF; // En yüksek byte
    payload[12] = 0x03; // In
    payload[14] = 0x03; // Out

    GPS_Send_UBX(huart, 0x06, 0x00, payload, 20);
    HAL_Delay(delay_ms);
}

/**
  * @brief  Sets the GPS Update Rate using UBX-CFG-RATE.
  * @param  huart: Pointer to UART handle
  * @param  period_ms: Measurement period in milliseconds (e.g., 100 for 10Hz)
  * @param  delay_ms: Delay after sending command
  * @retval None
  */
void GPS_Set_Rate(UART_HandleTypeDef *huart, uint16_t period_ms, int delay_ms){
    uint8_t payload[6] = {0};

    payload[0] = period_ms & 0xFF;
    payload[1] = (period_ms >> 8) & 0xFF;
    payload[2] = 0x01;
    payload[4] = 0x01;

    GPS_Send_UBX(huart, 0x06, 0x08, payload, 6);
    HAL_Delay(delay_ms);
}

/**
  * @brief  Saves current configuration to BBR and Flash using UBX-CFG-CFG.
  * @note   Ensures settings persist after power cycle if battery is present.
  * @param  huart: Pointer to UART handle
  * @retval None
  */
void GPS_Save_Configuration(UART_HandleTypeDef *huart) {
    uint8_t payload[13] = {0};
    payload[4] = 0xFF;
    payload[5] = 0xFF;
    payload[6] = 0x00;
    payload[7] = 0x00;
    payload[12] = 0x07;

    GPS_Send_UBX(huart, 0x06, 0x09, payload, 13);
}
void GPS_Configration_Full(UART_HandleTypeDef *huart, int BaudRate, int Period_ms, int minAngle, int GPS_PowerMode, int GPS_DynamicModel){
	GPS_Configure_System9600toAny(huart, BaudRate, Period_ms);
	GPS_Enable_Galileo_GLONASS(huart);
	GPS_Set_DynamicModel(huart, GPS_DynamicModel);
	GPS_Set_MinElevation(huart, minAngle);
	GPS_Set_PowerMode(huart, GPS_PowerMode);
	GPS_Save_Configuration(huart);
	memset(rxBuffer, 0, GPS_BUFFER_SIZE);
	GPS_Init(huart);
}

/**
  * @brief  Full system configuration routine for Cold Start scenarios.
  * @note   1. Starts at 9600 baud.
  * 2. Switches module to target baud rate.
  * 3. Switches STM32 UART to target baud rate.
  * 4. Sets update rate (Hz).
  * 5. Saves configuration.
  * @param  huart: Pointer to UART handle
  * @param  targetBaudRate: Target baud rate (e.g., 115200)
  * @param  updatePeriod_ms: Update period (e.g., 100ms)
  * @retval None
  */
void GPS_Configure_System9600toAny(UART_HandleTypeDef *huart, uint32_t targetBaudRate, uint16_t updatePeriod_ms) {
    HAL_Delay(3000);

    huart->Init.BaudRate = 9600;
    if (HAL_UART_Init(huart) != HAL_OK) {
        while(1);
    }

    GPS_Set_BaudRate(huart, targetBaudRate, 600);

    HAL_UART_Abort(huart);
    HAL_UART_DeInit(huart);

    huart->Init.BaudRate = targetBaudRate;
    if (HAL_UART_Init(huart) != HAL_OK) {
        while(1);
    }

    __HAL_UART_CLEAR_OREFLAG(huart);
    __HAL_UART_CLEAR_NEFLAG(huart);
    __HAL_UART_CLEAR_FEFLAG(huart);
    __HAL_UART_CLEAR_IDLEFLAG(huart);

    HAL_Delay(100);
    GPS_Set_Rate(huart, updatePeriod_ms, 200);

    GPS_Save_Configuration(huart);
    HAL_Delay(1000);

    memset(rxBuffer, 0, GPS_BUFFER_SIZE);
    GPS_Init(huart);
}

/**
  * @brief  Sets the Dynamic Platform Model using UBX-CFG-NAV5.
  * @param  huart: Pointer to UART handle
  * @param  model: Dynamic model enum (e.g., AIRBORNE_1G, PEDESTRIAN)
  * @retval None
  */
void GPS_Set_DynamicModel(UART_HandleTypeDef *huart, GPS_DynamicModel model) {
    uint8_t payload[36] = {0};

    payload[0] = 0x01;
    payload[1] = 0x00;

    payload[2] = (uint8_t)model;

    GPS_Send_UBX(huart, 0x06, 0x24, payload, 36);
    HAL_Delay(100);
}


/**
  * @brief  Enables Galileo and GLONASS constellations using UBX-CFG-GNSS.
  * @note   Significantly improves satellite count and precision.
  * @param  huart: Pointer to UART handle
  * @retval None
  */
void GPS_Enable_Galileo_GLONASS(UART_HandleTypeDef *huart) {
	uint8_t payload[] = {
        0x00, 0x00, 0x20, 0x00,

        // 1. GPS (Enable)
        0x00, 0x08, 0x10, 0x00, 0x01, 0x00, 0x01, 0x01,

        // 2. SBAS (Enable) - Hassasiyet artırıcı
        0x01, 0x02, 0x03, 0x00, 0x01, 0x00, 0x01, 0x01,

        // 3. Galileo (Enable)
        0x02, 0x04, 0x08, 0x00, 0x01, 0x00, 0x01, 0x01,

        // 4. GLONASS (Enable)
        0x06, 0x08, 0x0E, 0x00, 0x01, 0x00, 0x01, 0x01
    };

    GPS_Send_UBX(huart, 0x06, 0x3E, payload, sizeof(payload));
    HAL_Delay(500);
}

/**
  * @brief  Forces a specific type of reset (Cold/Warm/Hot) using UBX-CFG-RST.
  * @param  huart: Pointer to UART handle
  * @param  type: Reset type enum
  * @retval None
  */
void GPS_Force_Reset(UART_HandleTypeDef *huart, GPS_ResetType type) {
    uint8_t payload[4];

    if (type == GPS_RESET_COLD) {
        payload[0] = 0xFF; payload[1] = 0xFF;
    } else if (type == GPS_RESET_WARM) {
        payload[0] = 0x01; payload[1] = 0x00;
    } else {
        payload[0] = 0x00; payload[1] = 0x00;
    }

    payload[2] = 0x02; // resetMode: 0x02 (Controlled GNSS Stop/Start)
    payload[3] = 0x00;

    // Class: 0x06 (CFG), ID: 0x04 (RST)
    GPS_Send_UBX(huart, 0x06, 0x04, payload, 4);
    if(type == GPS_RESET_COLD) HAL_Delay(1000);
}

/**
  * @brief  Sets the Minimum Elevation Mask using UBX-CFG-NAV5.
  * @note   Satellites below this angle (degrees) will be ignored to prevent multipath.
  * @param  huart: Pointer to UART handle
  * @param  minAngle: Angle in degrees (e.g., 10 or 15)
  * @retval None
  */
void GPS_Set_MinElevation(UART_HandleTypeDef *huart, uint8_t minAngle) {
    uint8_t payload[36] = {0};

    // mask: Min Elevation ayarını değiştireceğimizi belirt (Bit 1 ve 2)
    payload[0] = 0x06;
    payload[1] = 0x00;
    // minElev: Derece (int8) - Payload[14]
    payload[14] = minAngle;
    // Class: 0x06 (CFG), ID: 0x24 (NAV5)

    GPS_Send_UBX(huart, 0x06, 0x24, payload, 36);
}

/**
  * @brief  Polls the security status (Jamming/Spoofing) using UBX-MON-HW.
  * @note   Response is parsed in GPS_Process function.
  * @param  huart: Pointer to UART handle
  * @retval None
  */
void GPS_Poll_Security_Status(UART_HandleTypeDef *huart) {
    GPS_Send_UBX(huart, 0x0A, 0x09, NULL, 0);
}

/**
  * @brief  Periodic Jammer control logic.
  * @note   Should be called periodically in the main loop.
  * @param  huart: Pointer to UART handle
  * @retval None
  */
void GPS_Jammer_Control(UART_HandleTypeDef *huart){
	static uint32_t lastCheck = 0;
	if (HAL_GetTick() - lastCheck > 2000) {
		lastCheck = HAL_GetTick();

		GPS_Poll_Security_Status(huart);
	}

	if(gps.newDataAvailable) {
		gps.newDataAvailable = 0;
		GPS_Calculate_Navigation();

		if (gps.security.jammingState > 0) {

		}
	}
}

/**
  * @brief  Sets the Power Management Mode using UBX-CFG-PMS.
  * @param  huart: Pointer to UART handle
  * @param  mode: Power mode enum (e.g., BALANCED, POWERSAVE)
  * @retval None
  */
void GPS_Set_PowerMode(UART_HandleTypeDef *huart, GPS_PowerMode mode) {
    uint8_t payload[8] = {0};

    payload[0] = 0x00;
    payload[1] = (uint8_t)mode;

    GPS_Send_UBX(huart, 0x06, 0x86, payload, 8);
}

/********************************************* FOR DRONE NAVIGATION **************************************************************/

/**
  * @brief  Initializes the Waypoint Route Manager.
  * @param  radiusMeters: Acceptance radius to consider a waypoint "reached"
  * @retval None
  */
void GPS_Route_Init(float radiusMeters) {
    gps.route.totalCount = 0;
    gps.route.currentIndex = 0;
    gps.route.isFinished = 0;
    gps.route.isActive = 0;
    gps.route.acceptanceRadius = radiusMeters; // Örn: 3.0 metre
}

/**
  * @brief  Adds a new coordinate point to the current route.
  * @param  lat: Latitude of the waypoint
  * @param  lon: Longitude of the waypoint
  * @retval None
  */
void GPS_Route_Add(float lat, float lon) {
    if (gps.route.totalCount < MAX_WAYPOINTS) {
        gps.route.points[gps.route.totalCount].lat = lat;
        gps.route.points[gps.route.totalCount].lon = lon;
        gps.route.totalCount++;
    }
}

/**
  * @brief  Starts following the loaded route from the beginning.
  * @retval None
  */
void GPS_Route_Start(void) {
    if (gps.route.totalCount > 0) {
        gps.route.currentIndex = 0;
        gps.route.isFinished = 0;
        gps.route.isActive = 1;

        // İlk hedefi GPS sistemine yükle
        GPS_Set_Target(gps.route.points[0].lat, gps.route.points[0].lon);
    }
}

/**
  * @brief  Updates route logic (Distance check and waypoint switching).
  * @note   Must be called periodically after navigation calculations.
  * @retval None
  */
void GPS_Route_Update(void) {
    // Rota aktif değilse veya bittiyse işlem yapma
    if (!gps.route.isActive || gps.route.isFinished) return;

    // ŞU ANKİ HEDEFE OLAN MESAFE (GPS_Calculate_Navigation ile hesaplanmış olmalı)
    float distance = gps.nav.distanceMeters;

    // Hedefe yeterince yaklaştık mı?
    if (distance <= gps.route.acceptanceRadius) {

        // Bir sonraki noktaya geç
        gps.route.currentIndex++;

        // Liste bitti mi kontrol et
        if (gps.route.currentIndex >= gps.route.totalCount) {
            gps.route.isFinished = 1;
            gps.route.isActive = 0; // Sistemi durdur
            // Burada "Görev Tamamlandı" sesi veya LED'i yakılabilir.
        }
        else {
            // Yeni hedefi yükle
            GPS_Waypoint nextPoint = gps.route.points[gps.route.currentIndex];
            GPS_Set_Target(nextPoint.lat, nextPoint.lon);
        }
    }
}

/**
  * @brief  Sets a single navigation target coordinate.
  * @param  lat: Target Latitude
  * @param  lon: Target Longitude
  * @retval None
  */
void GPS_Set_Target(float lat, float lon) {
    gps.target.targetLat = lat;
    gps.target.targetLon = lon;
}

/**
  * @brief  Converts degrees to radians.
  * @param  degree: Angle in degrees
  * @retval Angle in radians
  */
float toRadians(float degree) {
    return degree * TO_RAD;
}

/**
  * @brief  Converts radians to degrees.
  * @param  radians: Angle in radians
  * @retval Angle in degrees
  */
float toDegrees(float radians) {
    return radians * TO_DEG;
}

/**
  * @brief  Calculates Distance, Bearing, and Course Error to the target.
  * @note   Uses Haversine formula for distance.
  * Calculates bearing and compares with current heading for error.
  *
  * @retval None
  */
void GPS_Calculate_Navigation(void) {
    if(gps.location.latitude == 0.0f) return;

    float lat1 = toRadians(gps.location.latitude);
    float lon1 = toRadians(gps.location.longitude);
    float lat2 = toRadians(gps.target.targetLat);
    float lon2 = toRadians(gps.target.targetLon);

    float dLat = lat2 - lat1;
    float dLon = lon2 - lon1;

    float a = sinf(dLat / 2) * sinf(dLat / 2) +
              cosf(lat1) * cosf(lat2) *
              sinf(dLon / 2) * sinf(dLon / 2);

    float c = 2 * atan2f(sqrtf(a), sqrtf(1 - a));

    gps.nav.distanceMeters = EARTH_RADIUS * c;

    float y = sinf(dLon) * cosf(lat2);
    float x = cosf(lat1) * sinf(lat2) -
              sinf(lat1) * cosf(lat2) * cosf(dLon);

    float bearing = toDegrees(atan2f(y, x));

    if(bearing < 0) {
        bearing += 360.0f;
    }

    gps.nav.bearingDegree = bearing;
    float currentHeading = gps.motion.courseDegree;

    float error = gps.nav.bearingDegree - currentHeading;

    if (error > 180) error -= 360;
    if (error < -180) error += 360;

    gps.nav.errorDegree = error;
}

void GPS_Route_Check(void){
	if(gps.newDataAvailable) {
		gps.newDataAvailable = 0;
		GPS_Calculate_Navigation();
		GPS_Route_Update();
		/*if (gps.route.isFinished) {
		}else{
		}*/
	}
}
