/*
 * MPU9250_fnc.c
 *
 *  Created on: Dec 5, 2025
 *      Author: k4chinas
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "MPU9250_I2C.h"
#include "MPU9250_addr.h"

void MPU9250_Sensivity_Selector(MPU9250_I2C *mpu, Accel_Scale aScale, Gyro_Scale gScale){
	mpu->aScale = aScale;
	mpu->gScale = gScale;

	//For Acceleration
	switch(aScale) {
	case ACCEL_SCALE_2G:  mpu->aMult = 1.0f / 16384.0f; break;
	case ACCEL_SCALE_4G:  mpu->aMult = 1.0f / 8192.0f;  break;
	case ACCEL_SCALE_8G:  mpu->aMult = 1.0f / 4096.0f;  break;
	case ACCEL_SCALE_16G: mpu->aMult = 1.0f / 2048.0f;  break;
	default: mpu->aMult = 1.0f / 16384.0f; break;
	}

	//For Gyro:
	switch(gScale) {
	case GYRO_SCALE_250DPS:  mpu->gMult = 1.0f / 131.0f;  break;
	case GYRO_SCALE_500DPS:  mpu->gMult = 1.0f / 65.5f;   break;
	case GYRO_SCALE_1000DPS: mpu->gMult = 1.0f / 32.8f;   break;
	case GYRO_SCALE_2000DPS: mpu->gMult = 1.0f / 16.4f;   break;
	default: mpu->gMult = 1.0f / 131.0f; break;
	}
}

uint8_t MPU9250_Init(MPU9250_I2C *mpu, I2C_HandleTypeDef *hi2c,Accel_Scale aScale, Gyro_Scale gScale){
	uint8_t check;
	uint8_t data;
	mpu->hi2c = hi2c;

	MPU9250_Sensivity_Selector(mpu, aScale, gScale);
	HAL_I2C_Mem_Read(mpu->hi2c, MPU9250_ADDR, WHO_AM_I, 1, &check, 1, 100);

	if (check == 0x71){
		data = 0x00;
		HAL_I2C_Mem_Write(mpu->hi2c, MPU9250_ADDR, PWR_MGMT_1, 1, &data, 1, 100);

		data = (uint8_t)mpu->gScale;
		HAL_I2C_Mem_Write(mpu->hi2c, MPU9250_ADDR, GYRO_CONFIG, 1, &data, 1, 100);

		data = (uint8_t)mpu->aScale;
		HAL_I2C_Mem_Write(mpu->hi2c, MPU9250_ADDR, ACCEL_CONFIG, 1, &data, 1, 100);

		MPU9250_Calibrate(mpu);

		uint8_t dlpf_cfg = 0x03;
		HAL_I2C_Mem_Write(mpu->hi2c, MPU9250_ADDR, CONFIG, 1, &dlpf_cfg, 1, 100);
		uint8_t accel_dlpf = 0x03;
		HAL_I2C_Mem_Write(mpu->hi2c, MPU9250_ADDR, ACCEL_CONFIG_2, 1, &accel_dlpf, 1, 100);
		return 0;
	}
		return 1;
}

void MPU9250_Calibrate(MPU9250_I2C *mpu){
		int32_t accel_bias[3] = {0, 0, 0};
	    int32_t gyro_bias[3] = {0, 0, 0};

	    uint8_t Accel_Raw[6];
	    uint8_t Gyro_Raw[6];

	    int16_t temp_ax, temp_ay, temp_az;
	    int16_t temp_gx, temp_gy, temp_gz;

	    for(int i=0; i<100; i++) {
	    	HAL_I2C_Mem_Read(mpu->hi2c, MPU9250_ADDR, ACCEL_XOUT_H, 1, Accel_Raw, 6, 100);

	    	temp_ax = (int16_t)(Accel_Raw[0] << 8 | Accel_Raw[1]);
	        temp_ay = (int16_t)(Accel_Raw[2] << 8 | Accel_Raw[3]);
	        temp_az = (int16_t)(Accel_Raw[4] << 8 | Accel_Raw[5]);

	        HAL_I2C_Mem_Read(mpu->hi2c, MPU9250_ADDR, GYRO_XOUT_H, 1, Gyro_Raw, 6, 100);
	        temp_gx = (int16_t)(Gyro_Raw[0] << 8 | Gyro_Raw[1]);
	        temp_gy = (int16_t)(Gyro_Raw[2] << 8 | Gyro_Raw[3]);
	        temp_gz = (int16_t)(Gyro_Raw[4] << 8 | Gyro_Raw[5]);

	        accel_bias[0] += temp_ax;
	        accel_bias[1] += temp_ay;
	        accel_bias[2] += temp_az;

	        gyro_bias[0] += temp_gx;
	        gyro_bias[1] += temp_gy;
	        gyro_bias[2] += temp_gz;

	        HAL_Delay(5);
	        }

	    mpu->Accel_Offset[0] = (float)accel_bias[0] / 100.0f;
	    mpu->Accel_Offset[1] = (float)accel_bias[1] / 100.0f;
	    mpu->Accel_Offset[2] = ((float)accel_bias[2] / 100.0f) - (1.0f / mpu->aMult);

	    mpu->Gyro_Offset[0] = (float)gyro_bias[0] / 100.0f;
	    mpu->Gyro_Offset[1] = (float)gyro_bias[1] / 100.0f;
	    mpu->Gyro_Offset[2] = (float)gyro_bias[2] / 100.0f;
}

void MPU9250_Read_All(MPU9250_I2C *mpu) {
    uint8_t Accel_Raw[6];
    uint8_t Gyro_Raw[6];

    uint8_t Temp_Raw[2];
    int16_t Temp_Prev;

    HAL_I2C_Mem_Read(mpu->hi2c, MPU9250_ADDR, ACCEL_XOUT_H, 1, Accel_Raw, 6, 100);
    mpu->Accel_Raw[0] = (int16_t)(Accel_Raw[0] << 8 | Accel_Raw[1]);
    mpu->Accel_Raw[1] = (int16_t)(Accel_Raw[2] << 8 | Accel_Raw[3]);
    mpu->Accel_Raw[2] = (int16_t)(Accel_Raw[4] << 8 | Accel_Raw[5]);

    mpu->Ax = ((float)mpu->Accel_Raw[0] - mpu->Accel_Offset[0]) * mpu->aMult;
    mpu->Ay = ((float)mpu->Accel_Raw[1] - mpu->Accel_Offset[1]) * mpu->aMult;
    mpu->Az = ((float)mpu->Accel_Raw[2] - mpu->Accel_Offset[2]) * mpu->aMult;

    HAL_I2C_Mem_Read(mpu->hi2c, MPU9250_ADDR, GYRO_XOUT_H, 1, Gyro_Raw, 6, 100);
    mpu->Gyro_Raw[0] = (int16_t)(Gyro_Raw[0] << 8 | Gyro_Raw[1]);
    mpu->Gyro_Raw[1] = (int16_t)(Gyro_Raw[2] << 8 | Gyro_Raw[3]);
    mpu->Gyro_Raw[2] = (int16_t)(Gyro_Raw[4] << 8 | Gyro_Raw[5]);

    mpu->Gx = ((float)mpu->Gyro_Raw[0] - mpu->Gyro_Offset[0]) * mpu->gMult;
    mpu->Gy = ((float)mpu->Gyro_Raw[1] - mpu->Gyro_Offset[1]) * mpu->gMult;
    mpu->Gz = ((float)mpu->Gyro_Raw[2] - mpu->Gyro_Offset[2]) * mpu->gMult;

    HAL_I2C_Mem_Read(mpu->hi2c, MPU9250_ADDR, TEMP_OUT_H, 1, Temp_Raw, 2, 100);
    Temp_Prev = (int16_t)(Temp_Raw[0] << 8 | Temp_Raw[1]);
    mpu->Temperature = ((float)Temp_Prev / 333.87f) + 21.0f;

    float alpha = 0.2f; //Change your filter setting by adjusting it between 0.1 and 0.9.

        if(mpu->Ax_Filt == 0) {
            mpu->Ax_Filt = mpu->Ax;
            mpu->Ay_Filt = mpu->Ay;
            mpu->Az_Filt = mpu->Az;
        }

        // Formula: w Filter = (Alpha * New Data) + ((1 - Alpha) * old Filter Data)
        mpu->Ax_Filt = (alpha * mpu->Ax) + ((1.0f - alpha) * mpu->Ax_Filt);
        mpu->Ay_Filt = (alpha * mpu->Ay) + ((1.0f - alpha) * mpu->Ay_Filt);
        mpu->Az_Filt = (alpha * mpu->Az) + ((1.0f - alpha) * mpu->Az_Filt);

        if(mpu->Mx_Filt == 0) mpu->Mx_Filt = mpu->Mx;
        mpu->Mx_Filt = (alpha * mpu->Mx) + ((1.0f - alpha) * mpu->Mx_Filt);
        mpu->My_Filt = (alpha * mpu->My) + ((1.0f - alpha) * mpu->My_Filt);
        mpu->Mz_Filt = (alpha * mpu->Mz) + ((1.0f - alpha) * mpu->Mz_Filt);
}

void MPU9250_Degree(MPU9250_I2C *mpu){

	mpu->Angle_X = atan2(mpu->Ay_Filt, mpu->Az_Filt) * 57.296f;
	mpu->Angle_Y = atan2(-(mpu->Ax_Filt), sqrt(mpu->Ay_Filt * mpu->Ay_Filt + mpu->Az_Filt * mpu->Az_Filt)) * 57.296f;

    //mpu->Angle_X = atan2(mpu->Ay, mpu->Az) * 57.296f;
    //mpu->Angle_Y = atan2(-(mpu->Ax), sqrt(mpu->Ay * mpu->Ay + mpu->Az * mpu->Az)) * 57.296f;

    float roll_rad = mpu->Angle_X * (3.14159f / 180.0f);   // Phi
    float pitch_rad = mpu->Angle_Y * (3.14159f / 180.0f); // Theta

    float X_mag = mpu->Mx * cos(pitch_rad) + mpu->Mz * sin(pitch_rad);
    float Y_mag = mpu->Mx * sin(roll_rad) * sin(pitch_rad) + mpu->My * cos(roll_rad) - mpu->Mz * sin(roll_rad) * cos(pitch_rad);

    float yaw_rad = atan2(Y_mag, X_mag);
    float yaw_deg = yaw_rad * (180.0f / 3.14159f);

    if (yaw_deg < 0) {
        yaw_deg += 360.0f;
    }

    mpu->Angle_Z = yaw_deg;
}

void MPU9250_Mag_Init(MPU9250_I2C *mpu) {
    uint8_t data;
    uint8_t raw_asa[3];
    data = 0x02;
    HAL_I2C_Mem_Write(mpu->hi2c, MPU9250_ADDR, INT_PIN_CFG, 1, &data, 1, 100);
    HAL_Delay(10);

     uint8_t whoami_mag;
     HAL_I2C_Mem_Read(mpu->hi2c, AK8963_I2C_ADDR, AK8963_WIA, 1, &whoami_mag, 1, 100);
     if(whoami_mag != 0x48) return;

    data = 0x00;
    HAL_I2C_Mem_Write(mpu->hi2c, AK8963_I2C_ADDR, AK8963_CNTL1, 1, &data, 1, 100);
    HAL_Delay(10);

    data = 0x0F;
    HAL_I2C_Mem_Write(mpu->hi2c, AK8963_I2C_ADDR, AK8963_CNTL1, 1, &data, 1, 100);
    HAL_Delay(10);

    HAL_I2C_Mem_Read(mpu->hi2c, AK8963_I2C_ADDR, AK8963_ASAX, 1, raw_asa, 3, 100);

    mpu->Mag_Adjustment[0] = (float)(raw_asa[0] - 128) / 256.0f + 1.0f;
    mpu->Mag_Adjustment[1] = (float)(raw_asa[1] - 128) / 256.0f + 1.0f;
    mpu->Mag_Adjustment[2] = (float)(raw_asa[2] - 128) / 256.0f + 1.0f;

    data = 0x00;
    HAL_I2C_Mem_Write(mpu->hi2c, AK8963_I2C_ADDR, AK8963_CNTL1, 1, &data, 1, 100);
    HAL_Delay(10);

    data = 0x16;
    HAL_I2C_Mem_Write(mpu->hi2c, AK8963_I2C_ADDR, AK8963_CNTL1, 1, &data, 1, 100);
}

void MPU9250_Mag_Read(MPU9250_I2C *mpu) {
    uint8_t raw_data[7];
    uint8_t st1;

    HAL_I2C_Mem_Read(mpu->hi2c, AK8963_I2C_ADDR, AK8963_ST1, 1, &st1, 1, 100);

    if ((st1 & 0x01)) {
        HAL_I2C_Mem_Read(mpu->hi2c, AK8963_I2C_ADDR, AK8963_HXL, 1, raw_data, 7, 100);

        int16_t mx_raw = (int16_t)(raw_data[1] << 8 | raw_data[0]);
        int16_t my_raw = (int16_t)(raw_data[3] << 8 | raw_data[2]);
        int16_t mz_raw = (int16_t)(raw_data[5] << 8 | raw_data[4]);

        if (!(raw_data[6] & 0x08)) {

            mpu->Mx = (float)mx_raw * mpu->Mag_Adjustment[0] * 0.15f; // 0.15uT/LSB
            mpu->My = (float)my_raw * mpu->Mag_Adjustment[1] * 0.15f;
            mpu->Mz = (float)mz_raw * mpu->Mag_Adjustment[2] * 0.15f;
        }
    }
}
