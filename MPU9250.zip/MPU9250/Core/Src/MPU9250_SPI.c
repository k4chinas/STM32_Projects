/*
 * MPU9250_SPI.c
 *
 *  Created on: Dec 6, 2025
 *      Author: k4chinas
 */

#include "MPU9250_SPI.h"

void MPU9250_Write_Reg(uint8_t reg, uint8_t data){
	uint8_t txData[2] = {reg, data};
	HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi1, txData, 2, 100);
	HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_SET);
}
void MPU9250_SPIInit(void){
	MPU9250_Write_Reg(PWR_MGMT_1, 0x80);
	HAL_Delay(100);

	MPU9250_Write_Reg(PWR_MGMT_1, 0x01);
	HAL_Delay(100);
}
uint8_t MPU9250_WhoAmI(void){
	uint8_t response = 0;

		MPU9250_Write_Reg(INT_PIN_CFG, 0x00);
	    HAL_Delay(10);


	    MPU9250_Write_Reg(USER_CTRL, 0x12);
	    HAL_Delay(50);

	    MPU9250_Write_Reg(USER_CTRL, 0x30);
	    HAL_Delay(10);

	    MPU9250_Write_Reg(I2C_MST_CTRL, 0x0D);
	    HAL_Delay(10);

	    MPU9250_Write_Reg(I2C_SLV0_ADDR, AK8963_I2C_ADDR | 0x80);
	    MPU9250_Write_Reg(I2C_SLV0_REG, AK8963_WIA);
	    MPU9250_Write_Reg(I2C_SLV0_CTRL, 0x81);
	    HAL_Delay(100);

	    uint8_t regAddr = EXT_SENS_DATA_00 | SPI_READ_FLAG;
	    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_RESET);
	    HAL_SPI_Transmit(&hspi1, &regAddr, 1, 100);
	    HAL_SPI_Receive(&hspi1, &response, 1, 100);
	    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_SET);

	    return response;
}

void MPU9250_Read_Accel(MPU9250_SPI *mpu){
	uint8_t regAccel = ACCEL_XOUT_H | SPI_READ_FLAG;
	uint8_t rxAccel[6];

    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &regAccel, 1, 100);
    HAL_SPI_Receive(&hspi1, rxAccel, 6, 100);
    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_SET);

    mpu->Accel_Raw[0] =(int16_t)(rxAccel[0] << 8 | rxAccel[1]);
    mpu->Accel_Raw[1] =(int16_t)(rxAccel[2] << 8 | rxAccel[3]);
    mpu->Accel_Raw[2] =(int16_t)(rxAccel[4] << 8 | rxAccel[5]);
}

void MPU9250_Read_Gyro(MPU9250_SPI *mpu){
	uint8_t regGyro = GYRO_XOUT_H | SPI_READ_FLAG;
	uint8_t rxGyro[6];

    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &regGyro, 1, 100);
    HAL_SPI_Receive(&hspi1, rxGyro, 6, 100);
    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_SET);

    mpu->Gyro_Raw[0] =(int16_t)(rxGyro[0] << 8 | rxGyro[1]);
    mpu->Gyro_Raw[1] =(int16_t)(rxGyro[2] << 8 | rxGyro[3]);
    mpu->Gyro_Raw[2] =(int16_t)(rxGyro[4] << 8 | rxGyro[5]);
}

void MPU9250_Read_Temperature(MPU9250_SPI *mpu){
	uint8_t regTemp = TEMP_OUT_H | SPI_READ_FLAG;
	uint8_t rxTemp[2];

    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &regTemp, 1, 100);
    HAL_SPI_Receive(&hspi1, rxTemp, 2, 100);
    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_SET);

    mpu->Temprature_Raw =(int16_t)(rxTemp[0] << 8 | rxTemp[1]);
}

void MPU9250_Sensivity_Select(MPU9250_SPI *mpu,Accel_Scale aScale, Gyro_Scale gScale){
	mpu->aScale = aScale;
	mpu->gScale = gScale;
	switch(aScale) {
	case ACCEL_SCALE_2G:  mpu->aMult = 1.0f / 16384.0f; break;
	case ACCEL_SCALE_4G:  mpu->aMult = 1.0f / 8192.0f;  break;
	case ACCEL_SCALE_8G:  mpu->aMult = 1.0f / 4096.0f;  break;
	case ACCEL_SCALE_16G: mpu->aMult = 1.0f / 2048.0f;  break;
	default: mpu->aMult = 1.0f / 16384.0f; break;
	}
	    // Gyro için:
	switch(gScale) {
	case GYRO_SCALE_250DPS:  mpu->gMult = 1.0f / 131.0f;  break;
	case GYRO_SCALE_500DPS:  mpu->gMult = 1.0f / 65.5f;   break;
	case GYRO_SCALE_1000DPS: mpu->gMult = 1.0f / 32.8f;   break;
	case GYRO_SCALE_2000DPS: mpu->gMult = 1.0f / 16.4f;   break;
	default: mpu->gMult = 1.0f / 131.0f; break;
	}
}

void MPU9250_Process_Data(MPU9250_SPI *mpu){
	mpu->Ax = (float)mpu->Accel_Raw[0] * mpu->aMult;
	mpu->Ay = (float)mpu->Accel_Raw[1] * mpu->aMult;
	mpu->Az = (float)mpu->Accel_Raw[2] * mpu->aMult;

	mpu->Gx = (float)mpu->Gyro_Raw[0] * mpu->gMult;
	mpu->Gy = (float)mpu->Gyro_Raw[1] * mpu->gMult;
	mpu->Gz = (float)mpu->Gyro_Raw[2] * mpu->gMult;

	mpu->Temperature = ((float)mpu->Temprature_Raw / 333.87f) + 21.0f;
}

void MPU9250_Init_Magnetometer(void) {
    MPU9250_Write_Reg(USER_CTRL, 0x20);
    MPU9250_Write_Reg(I2C_MST_CTRL, 0x0D);

    MPU9250_Write_Reg(I2C_SLV0_ADDR, AK8963_I2C_ADDR);
    MPU9250_Write_Reg(I2C_SLV0_REG, AK8963_CNTL2);
    MPU9250_Write_Reg(I2C_SLV0_DO, 0x01);
    MPU9250_Write_Reg(I2C_SLV0_CTRL, 0x81);
    HAL_Delay(50);

    MPU9250_Write_Reg(I2C_SLV0_ADDR, AK8963_I2C_ADDR);
    MPU9250_Write_Reg(I2C_SLV0_REG, AK8963_CNTL1);
    MPU9250_Write_Reg(I2C_SLV0_DO, 0x16);              // 0x16: 16-bit, Continuous 2
    MPU9250_Write_Reg(I2C_SLV0_CTRL, 0x81);
    HAL_Delay(10);

    MPU9250_Write_Reg(I2C_SLV0_ADDR, AK8963_I2C_ADDR | 0x80);
    MPU9250_Write_Reg(I2C_SLV0_REG, AK8963_HXL);
    MPU9250_Write_Reg(I2C_SLV0_CTRL, 0x80 | 0x07);

    HAL_Delay(10);
}

void MPU9250_Read_Mag(MPU9250_SPI *mpu) {
    uint8_t rawMag[7];
    uint8_t regAddr = EXT_SENS_DATA_00 | SPI_READ_FLAG;

    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &regAddr, 1, 100);
    HAL_SPI_Receive(&hspi1, rawMag, 7, 100);
    HAL_GPIO_WritePin(MPU_CS_PORT, MPU_CS_PIN, GPIO_PIN_SET);

    mpu->Mag_Raw[0] = (int16_t)(rawMag[1] << 8 | rawMag[0]); // X
    mpu->Mag_Raw[1] = (int16_t)(rawMag[3] << 8 | rawMag[2]); // Y
    mpu->Mag_Raw[2] = (int16_t)(rawMag[5] << 8 | rawMag[4]); // Z

    mpu->Mx = (float)mpu->Mag_Raw[0] * 0.15f;
    mpu->My = (float)mpu->Mag_Raw[1] * 0.15f;
    mpu->Mz = (float)mpu->Mag_Raw[2] * 0.15f;
}
