/*
 * MPU9250_fnc.h
 *
 *  Created on: Dec 5, 2025
 *      Author: orhun
 */

#ifndef INC_MPU9250_FNC_H_
#define INC_MPU9250_FNC_H_


#include <main.h>

typedef enum {
    ACCEL_SCALE_2G = 0x00,  // En Hassas
    ACCEL_SCALE_4G = 0x08,
    ACCEL_SCALE_8G = 0x10,
    ACCEL_SCALE_16G = 0x18  // En Kaba (Yüksek G)
}Accel_Scale;

typedef enum {
    GYRO_SCALE_250DPS  = 0x00, // En Hassas
    GYRO_SCALE_500DPS  = 0x08,
    GYRO_SCALE_1000DPS = 0x10,
    GYRO_SCALE_2000DPS = 0x18  // En Hızlı
}Gyro_Scale;

typedef struct {
    I2C_HandleTypeDef *hi2c;

    int16_t Accel_Raw[3];
    int16_t Gyro_Raw[3];

    float Ax, Ay, Az;
    float Gx, Gy, Gz;

    Accel_Scale aScale;
    Gyro_Scale gScale;

    float aMult; // Ham veriyi g'ye çeviren çarpan
    float gMult; // Ham veriyi dps'ye çeviren çarpan

    float Accel_Offset[3];
    float Gyro_Offset[3];

    float Temperature;

    float Angle_X;  // X ekseni etrafındaki açı (Sağa/Sola yatış)
    float Angle_Y; // Y ekseni etrafındaki açı (Öne/Arkaya yatış)
    float Angle_Z;

    int16_t Mag_Raw[3];
    float Mx, My, Mz;      // Gerçek Veri (µT - Mikro Tesla)
    float Mag_Adjustment[3];
}MPU9250_t;

void MPU9250_Sensivity_Selector(MPU9250_t *mpu,Accel_Scale aScale, Gyro_Scale gScale);
uint8_t MPU9250_Init(MPU9250_t *mpu, I2C_HandleTypeDef *hi2c,Accel_Scale aScale, Gyro_Scale gScale);
void MPU9250_Calibrate(MPU9250_t *mpu);
void MPU9250_Read_All(MPU9250_t *mpu);
void MPU9250_Degree(MPU9250_t *mpu);
void MPU9250_Mag_Init(MPU9250_t *mpu);
void MPU9250_Mag_Read(MPU9250_t *mpu);
#endif /* INC_MPU9250_FNC_H_ */
