/*
 * MPU9250_fnc.h
 *
 *  Created on: Dec 5, 2025
 *      Author: k4chinas
 */

#ifndef INC_MPU9250_I2C_H_
#define INC_MPU9250_I2C_H_


#include <main.h>
#include "MPU9250_addr.h"

typedef struct {
    I2C_HandleTypeDef *hi2c;

    int16_t Accel_Raw[3];
    int16_t Gyro_Raw[3];

    float Ax, Ay, Az;
    float Gx, Gy, Gz;

    Accel_Scale aScale;
    Gyro_Scale gScale;

    float aMult; // Multiplier converting raw data to g
    float gMult; // Multiplier converting raw data to dps

    float Accel_Offset[3];
    float Gyro_Offset[3];

    float Temperature;

    float Angle_X;  // Angle around the X axis (Roll)
    float Angle_Y; // Angle around the Y axis (Pitch)
    float Angle_Z;

    int16_t Mag_Raw[3];
    float Mx, My, Mz;      // Raw Data (µT - Micro Tesla)
    float Mag_Adjustment[3];

    float Ax_Filt, Ay_Filt, Az_Filt;
    float Mx_Filt, My_Filt, Mz_Filt;
}MPU9250_I2C;

void MPU9250_Sensivity_Selector(MPU9250_I2C *mpu,Accel_Scale aScale, Gyro_Scale gScale);
uint8_t MPU9250_Init(MPU9250_I2C *mpu, I2C_HandleTypeDef *hi2c,Accel_Scale aScale, Gyro_Scale gScale);
void MPU9250_Calibrate(MPU9250_I2C *mpu);

void MPU9250_Read_All(MPU9250_I2C *mpu);
void MPU9250_Degree(MPU9250_I2C *mpu);

void MPU9250_Mag_Init(MPU9250_I2C *mpu);
void MPU9250_Mag_Read(MPU9250_I2C *mpu);
#endif /* INC_MPU9250_I2C_H_ */
