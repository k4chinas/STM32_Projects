/*
 * MPU9250_SPI.h
 *
 *  Created on: Dec 6, 2025
 *      Author: k4chinas
 */

#ifndef INC_MPU9250_SPI_H_
#define INC_MPU9250_SPI_H_

#include "MPU9250_addr.h"
#include <main.h>
#include <stdio.h>
#include <stdlib.h>

extern SPI_HandleTypeDef hspi1;

#define MPU_CS_PORT   GPIOA
#define MPU_CS_PIN    GPIO_PIN_4

typedef struct {
    SPI_HandleTypeDef *hspi;

    int16_t Accel_Raw[3];
    int16_t Gyro_Raw[3];
    int16_t Temprature_Raw;

    Accel_Scale aScale;
    Gyro_Scale gScale;

    float aMult; // Multiplier converting raw data to g
    float gMult; // Multiplier converting raw data to dps

    float Ax, Ay, Az;
    float Gx, Gy, Gz;
    float Temperature;

    float Angle_X;  // Angle around the X axis (Pitch/Yaw)
    float Angle_Y; // Angle around the Y axis (Forward/Backward tilt)
    float Angle_Z;

    int16_t Mag_Raw[3];
    float Mx, My, Mz;      // Actual Data (µT - Micro Tesla)
    float Mag_Adjustment[3];
}MPU9250_SPI;

void MPU9250_Write_Reg(uint8_t reg, uint8_t data);
void MPU9250_SPIInit(void);
uint8_t MPU9250_WhoAmI(void);

void MPU9250_Read_Accel(MPU9250_SPI *mpu);
void MPU9250_Read_Gyro(MPU9250_SPI *mpu);
void MPU9250_Read_Temperature(MPU9250_SPI *mpu);

void MPU9250_Sensivity_Select(MPU9250_SPI *mpu,Accel_Scale aScale, Gyro_Scale gScale);
void MPU9250_Process_Data(MPU9250_SPI *mpu);

void MPU9250_Init_Magnetometer(void);
void MPU9250_Read_Mag(MPU9250_SPI *mpu);
#endif /* INC_MPU9250_SPI_H_ */
