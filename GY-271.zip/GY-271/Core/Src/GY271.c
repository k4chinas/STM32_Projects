/*
 * GY271.c
 *
 * Created on: Dec 30, 2025
 * Author: k4chinas
 */
#include "GY271.h"


void GY271_WriteControl1(GY271 *GY, uint8_t ConfigByte) {
    HAL_I2C_Mem_Write(GY->hi2c, GY271_Addr, QMC_CONTROL_1, 1, &ConfigByte, 1, 100);
}

void GY271_Init(GY271 *GY, I2C_HandleTypeDef *hi2c, GY271_Samples Sample, GY271_DataRate Rate, GY271_Range Range, GY271_Mode Mode){
    GY->hi2c = hi2c;

    uint8_t reset = 0x80;
    HAL_I2C_Mem_Write(GY->hi2c, GY271_Addr, QMC_CONTROL_2, 1, &reset, 1, 100);
    HAL_Delay(10);

    uint8_t period = 0x01;
    HAL_I2C_Mem_Write(GY->hi2c, GY271_Addr, QMC_PERIOD, 1, &period, 1, 100);

    uint8_t config = (Sample << 6) | (Range << 4) | (Rate << 2) | Mode;
    GY271_WriteControl1(GY, config);
}

void GY271_ReadRawData(GY271 *GY){
    uint8_t Data[6];

    if(HAL_I2C_Mem_Read(GY->hi2c, GY271_Addr, QMC_DATA_X_LSB, 1, Data, 6, 100) == HAL_OK){
        GY->X_Raw = (int16_t)((Data[1] << 8) | Data[0]);
        GY->Y_Raw = (int16_t)((Data[3] << 8) | Data[2]);
        GY->Z_Raw = (int16_t)((Data[5] << 8) | Data[4]);
    }
}

void GY271_ReadAll(GY271 *GY, GY271_Sensitivity Sensitivity, float declinationAngle){
    uint8_t status = 0;
    HAL_I2C_Mem_Read(GY->hi2c, GY271_Addr, QMC_STATUS, 1, &status, 1, 100);

    if((status & 0x01) == 0x01){
        GY271_ReadRawData(GY);

        if(Sensitivity > 0){
            GY->X_Mag = (float)GY->X_Raw / (float)Sensitivity;
            GY->Y_Mag = (float)GY->Y_Raw / (float)Sensitivity;
            GY->Z_Mag = (float)GY->Z_Raw / (float)Sensitivity;

            float Radian = atan2f(GY->Y_Mag, GY->X_Mag);
            Radian += declinationAngle;

            if(Radian < 0) Radian += 2 * M_PI;
            if(Radian > 2 * M_PI) Radian -= 2 * M_PI;

            GY->Heading = Radian * 180.0f / M_PI;
        }
    }
}
