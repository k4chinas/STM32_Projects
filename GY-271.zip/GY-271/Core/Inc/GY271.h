/*
 * GY271.h
 *
 *  Created on: Dec 30, 2025
 *      Author: k4chinas
 */

#ifndef INC_GY271_H_
#define INC_GY271_H_

#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define GY271_Addr      (0x0D << 1)

#define QMC_DATA_X_LSB  0x00
#define QMC_DATA_X_MSB  0x01
#define QMC_DATA_Y_LSB  0x02
#define QMC_DATA_Y_MSB  0x03
#define QMC_DATA_Z_LSB  0x04
#define QMC_DATA_Z_MSB  0x05
#define QMC_STATUS      0x06
#define QMC_TEMP_LSB    0x07
#define QMC_TEMP_MSB    0x08
#define QMC_CONTROL_1   0x09
#define QMC_CONTROL_2   0x0A
#define QMC_PERIOD      0x0B

#define M_PI 3.14159265358979323846


typedef enum {
    OSR_512 = 0x00,
    OSR_256 = 0x01,
    OSR_128 = 0x02,
    OSR_64  = 0x03
} GY271_Samples;

typedef enum {
    RANGE_2G = 0x00,
    RANGE_8G = 0x01
} GY271_Range;

typedef enum {
    SENSITIVITY_2G = 12000,
    SENSITIVITY_8G = 3000
} GY271_Sensitivity;

typedef enum {
    ODR_10Hz  = 0x00,
    ODR_50Hz  = 0x01,
    ODR_100Hz = 0x02,
    ODR_200Hz = 0x03
} GY271_DataRate;

typedef enum {
    Mode_Standby    = 0x00,
    Mode_Continuous = 0x01
} GY271_Mode;

typedef struct {
    I2C_HandleTypeDef *hi2c;

    int16_t X_Raw;
    int16_t Y_Raw;
    int16_t Z_Raw;

    float X_Mag;
    float Y_Mag;
    float Z_Mag;

    float Heading;
} GY271;

void GY271_Init(GY271 *GY, I2C_HandleTypeDef *hi2c, GY271_Samples Sample, GY271_DataRate Rate, GY271_Range Range, GY271_Mode Mode);
void GY271_ReadAll(GY271 *GY, GY271_Sensitivity Sensitivity, float declinationAngle);

#endif /* INC_GY271_H_ */
