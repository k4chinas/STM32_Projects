/*
 * GY63.h
 *
 *  Created on: Dec 30, 2025
 *      Author: k4chinas
 */

#ifndef INC_GY63_H_
#define INC_GY63_H_

#include "main.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#define GY63_RESET 0x1E
#define GY53_ADC_READ 0x00

#define T_ref 20
#define T_min -40
#define T_max 80

#define P_min 10
#define P_max 1200

typedef enum{
	POSR_8 		= 0x40,
	POSR_9 		= 0x42,
	POSR_10 	= 0x44,
	POSR_11 	= 0x46,
	POSR_12 	= 0x48
} Pressure_OSR;

typedef enum{
	TOSR_8 		= 0x50,
	TOSR_9 		= 0x52,
	TOSR_10 	= 0x54,
	TOSR_11 	= 0x56,
	TOSR_12 	= 0x58
} Temprature_OSR;

typedef enum{
	Pressure_Sens 	= 0xA2,
	P_Offset 		= 0xA4,
	TCS 			= 0xA6,
	TCO 			= 0xA8,
	T_REF			= 0xAA,
	TEMPSENS 		= 0xAC,
	CRC_V			= 0xAE
} PROM_Address;

typedef struct{
	uint16_t Pressure_Sens;
	uint16_t P_Offset;
	uint16_t TCS;
	uint16_t TCO;
	uint16_t T_REF;
	uint16_t TEMPSENS;
	uint16_t CRC_V;
}PROM_Data;

typedef struct{
	SPI_HandleTypeDef *hspi;
	GPIO_TypeDef* CS_Port;
	uint16_t CS;

	uint32_t Digital_Pressure;
	uint32_t Digital_Temprature;

	int32_t dT;
	int32_t TEMP;

	int64_t OFF;
	int64_t SENS;

	int32_t Pressure;

	float Temperature_C;
	float Altitude;
	PROM_Data PROM;

}GY63;

void GY63_Init(GY63 *GY, SPI_HandleTypeDef *hspi, GPIO_TypeDef* CS_PORT, uint16_t CS_PIN);
void GY63_SPI_Reset(GY63 *GY,SPI_HandleTypeDef *hspi);
void GY63_PROM_Read(GY63 *GY);
void GY63_Get_Data(GY63 *GY, uint8_t Temprature_OSR, uint8_t Pressure_OSR);
#endif /* INC_GY63_H_ */
