 /*
 * GY63.c
 *
 *  Created on: Dec 30, 2025
 *      Author: k4chinas
 */

#include "GY63.h"


void GY63_SPI_Reset(GY63 *GY,SPI_HandleTypeDef *hspi){
	GY->hspi = hspi;
	uint8_t Reset = GY63_RESET;

	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_RESET);
	HAL_SPI_Transmit(hspi, &Reset, 1, 10);
	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_SET);
	HAL_Delay(5);
}

static uint16_t GY63_PROM_Data(GY63 *GY, SPI_HandleTypeDef *hspi, uint8_t Command){
	uint8_t RxBuffer[2];
	uint16_t Data;
	GY->hspi = hspi;

	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_RESET);
	HAL_SPI_Transmit(hspi, &Command, 1, 10);
	HAL_SPI_Receive(hspi, RxBuffer, 2, 10);
	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_SET);

	Data = (RxBuffer[0] << 8) | RxBuffer[1];
	return Data;

}
void GY63_PROM_Read(GY63 *GY){
	GY->PROM.Pressure_Sens 	= GY63_PROM_Data(GY, GY->hspi, Pressure_Sens);
	GY->PROM.P_Offset 		= GY63_PROM_Data(GY, GY->hspi, P_Offset);
	GY->PROM.TCS 			= GY63_PROM_Data(GY, GY->hspi, TCS);
	GY->PROM.TCO 			= GY63_PROM_Data(GY, GY->hspi, TCO);
	GY->PROM.T_REF 			= GY63_PROM_Data(GY, GY->hspi, T_REF);
	GY->PROM.TEMPSENS 		= GY63_PROM_Data(GY, GY->hspi, TEMPSENS);
}

void GY63_Init(GY63 *GY, SPI_HandleTypeDef *hspi, GPIO_TypeDef* CS_PORT, uint16_t CS_PIN){
		GY->hspi = hspi;
		GY->CS_Port = CS_PORT;
		GY->CS = CS_PIN;

		HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_SET);
		HAL_Delay(10);

		GY63_SPI_Reset(GY, hspi);
		GY63_PROM_Read(GY);
}

void GY63_Temp(GY63 *GY, uint8_t Bit_value){
	uint8_t ADC_Get = GY53_ADC_READ;
	uint8_t RxBuffer[3];

	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_RESET);
	HAL_SPI_Transmit(GY->hspi, &Bit_value, 1, 10);
	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_SET);
	HAL_Delay(10);

	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_RESET);
	HAL_SPI_Transmit(GY->hspi, &ADC_Get, 1, 10);
	HAL_SPI_Receive(GY->hspi, RxBuffer, 3, 20);
	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_SET);

	GY->Digital_Temprature = (RxBuffer[0] << 16) | (RxBuffer[1] << 8) | (RxBuffer[2]);
}

void GY63_Pressure(GY63 *GY, uint8_t Bit_value){
	uint8_t ADC_Get = GY53_ADC_READ;
	uint8_t RxBuffer[3];

	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_RESET);
	HAL_SPI_Transmit(GY->hspi, &Bit_value, 1, 10);
	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_SET);
	HAL_Delay(10);

	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_RESET);
	HAL_SPI_Transmit(GY->hspi, &ADC_Get, 1, 10);
	HAL_SPI_Receive(GY->hspi, RxBuffer, 3, 20);
	HAL_GPIO_WritePin(GY->CS_Port, GY->CS, GPIO_PIN_SET);

	GY->Digital_Pressure = (RxBuffer[0] << 16) | (RxBuffer[1] << 8) | (RxBuffer[2]);
}

void GY63_Get_Data(GY63 *GY, uint8_t Temprature_OSR, uint8_t Pressure_OSR){
	GY63_Temp(GY, Temprature_OSR);
	GY63_Pressure(GY, Pressure_OSR);

	GY->dT = (int32_t)GY->Digital_Temprature - ((int32_t)GY->PROM.T_REF << 8);
	GY->TEMP  = 2000 + ((int64_t)GY->dT * GY->PROM.TEMPSENS >> 23);

	//GY->OFF = ((int64_t)GY->PROM.P_Offset << 16) + (((int64_t)GY->PROM.TCO * GY->dT) >> 7);
	GY->OFF = ((int64_t)GY->PROM.P_Offset << 17) + (((int64_t)GY->PROM.TCO * GY->dT) >> 6);
	//GY->SENS = ((int64_t)GY->PROM.Pressure_Sens << 15) + (((int64_t)GY->PROM.TCS * GY->dT) >> 8);
	GY->SENS = ((int64_t)GY->PROM.Pressure_Sens << 16) + (((int64_t)GY->PROM.TCS * GY->dT) >> 7);
	int64_t P_Calc = ((((int64_t)GY->Digital_Pressure * GY->SENS) >> 21) - GY->OFF) >> 15;
	GY->Pressure = (int32_t)P_Calc;


	GY->Temperature_C = (float)GY->TEMP / 100.0f;

	float current_pressure_pa = (float)GY->Pressure;
	float sea_level_pa = 101325.0f;
	GY->Altitude = 44330.0f * (1.0f - powf(current_pressure_pa / sea_level_pa, 0.1903f));
}
